

--
-- Metaadat
--
USE `phpmyadmin`;

--
-- A(z) users tábla metaadatai
--

--
-- Tábla csonkolása beszúrás előtt `pma__column_info`
--

TRUNCATE TABLE `pma__column_info`;
--
-- Tábla csonkolása beszúrás előtt `pma__table_uiprefs`
--

TRUNCATE TABLE `pma__table_uiprefs`;
--
-- Tábla csonkolása beszúrás előtt `pma__tracking`
--

TRUNCATE TABLE `pma__tracking`;
--
-- A(z) registration adatbázis metaadatai
--

--
-- Tábla csonkolása beszúrás előtt `pma__bookmark`
--

TRUNCATE TABLE `pma__bookmark`;
--
-- Tábla csonkolása beszúrás előtt `pma__relation`
--

TRUNCATE TABLE `pma__relation`;
--
-- Tábla csonkolása beszúrás előtt `pma__savedsearches`
--

TRUNCATE TABLE `pma__savedsearches`;
--
-- Tábla csonkolása beszúrás előtt `pma__central_columns`
--

TRUNCATE TABLE `pma__central_columns`;