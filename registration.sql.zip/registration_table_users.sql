
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--
-- Létrehozva: 2023. Ápr 21. 11:09
-- Utolsó frissítés: 2023. Ápr 21. 11:24
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(100) NOT NULL,
  `email` int(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- TÁBLA KAPCSOLATAI `users`:
--

--
-- Tábla csonkolása beszúrás előtt `users`
--

TRUNCATE TABLE `users`;
--
-- A tábla adatainak kiíratása `users`
--

INSERT DELAYED IGNORE INTO `users` (`username`, `email`, `password`) VALUES
('username', 0, 'b36b00b95fdbae9325b0f8b39028b92c'),
('user', 0, '25de8e517661c1f17b096c19da5cceb0');
